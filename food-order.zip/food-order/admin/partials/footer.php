   <!-- footer section starts-->
   <div class="footer">
            <div class="wrapper">
               <p class="text-center">2022 All Rights Reserved, wowFood. Developed by- <a href="#"> Pratiksha Chavan</a> </p>
            </div>
        </div>
    <!-- footer section ends-->
    </body>

</html>