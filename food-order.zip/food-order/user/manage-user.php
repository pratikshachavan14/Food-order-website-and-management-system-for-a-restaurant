<?php include('partials/menu.php'); ?>

        <!-- main content starts here -->
        <div class="main-content">
            <div class="wrapper">
                 <h1>Your Order</h1>
            </div> 
        </div>
        <!-- main content starts here -->

<?php include('partials/footer.php'); ?>