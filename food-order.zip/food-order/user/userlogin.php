

<?php include('../config/constants.php'); ?>

<html>
    <head>
        <title>Admin Login - Food Order System</title>
        <link rel="stylesheet" href="../css/admin.css">
    </head>
    <body>
        
      <div class="login">
         <h1 class="text-center">User Login</h1>
         <br><br><br>



            <!-- login form starts here -->
            <form action="" method="POST">
                    <div class="text-feild">
                        <input type="text" name="username" >
                        <span></span>
                        <label>Username</label> 
                    </div>
                    <div class="text-feild">
                        <input type="password" name="password" >
                        <span></span>
                        <label>Password</label>
                    </div>
            <div>
                <input type="submit" name="user-login-submit" value="Login" class="btn-primary">
            <br><br>
            </div>
            </form>



        <!-- login form ends here -->
           <!-- login form ends here -->
           <br></br>
         <p>Created by - <a href="#">Pratiksha Chavan</a></p>
      </div>

    </body>
</html>

<?php 
   
   //check whether the submit button clicked or not
   if(isset($_POST['user-login-submit']))
   {
       //process for login
       //1. get the data from login form
       echo $username = $_POST['username'];
       echo $password = $_POST['password'];

       //2. sql to check whether username and password exist or not
       $sql = "SELECT * FROM tbl_user WHERE username='$username' AND password='$password'";

       //3. execute the query
       $res = mysqli_query($conn, $sql);

       //4. count rows to check whether the user exists or not
       $count = mysqli_num_rows($res);

       if($count==1)
       {
           //user available
           $_SESSION['user-login'] = "<div class='success'>Login successfuly.</div>";
           //redirect to order page
           header('location:'.SITEURL.'foods.php');
       }
       else
       {
           //user not available
            //user available
            $_SESSION['user-login'] = "<div class='error'><b> Login Failed.Username and password didn't match.Try again.</b></div>";
            //redirect to order page
            header('location:'.SITEURL.);
       }

       
   }

?>
