<?php 

include('../config/constants.php'); 
//include('login-check.php');

?>


<html>
    <head>
        <title>User- home page</title>
        <link rel="stylesheet" href="../css/user.css">
    </head>

    <body>
        <!-- menu section starts here -->
        <div class="menu text-center">
            <div class="wrapper">
                <ul>
                    <li><a href="index.php">User profile</a></li>
                    <li><a href="manage-user.php">Orders</a></li>
                    <li><a href="#">Logout</a></li>
                </ul>
            </div>
        </div>
        <!-- menu section ends here -->