<link rel="stylesheet" href="../css/user.css">

<div class="main-content">
    <div class="wrapper">
         <h1>Signup your profile.</h1>

         <form action="" method="POST">

         <table class="tbl-30 text">
            <tr>
                <td>Full Name: </td></br>
                <td>
                    <input type="text" name="full_name" placeholder="Enter your name">
                </td>
            </tr>

            <tr>
                <td>Username: </td></br>
                <td>
                    <input type="text" name="username" placeholder="Enter your username">
                </td>
            </tr>

            <tr>
                <td>Email: </td></br>
                <td>
                    <input type="mail" name="user_email" placeholder="Enter your email">
                </td>
            </tr>

            <tr>
                <td>Contact number: </td></br>
                <td>
                    <input type="text" name="user_contact" placeholder="Enter your contact number">
                </td>
            </tr>

            <tr>
                <td>Address: </td></br>
                <td>
                   <textarea name="user_address"  cols="30" rows="3"></textarea>
                </td>
            </tr>

            <tr>
                <td>Password: </td>
                <td>
                    <input type="password" name="password" placeholder="Your password">
                </td>
            </tr>
        

            <tr>
                <td colspan="2">
                </br> <input type="submit" name="submit" value="Signup" class="btn-secondary">
                </td>
            </tr>

                
         </table>

         </form>
    </div>
</div>

<?php include('partials/footer.php') ?>

<?php 
     //process the data from form and save it to database
     //check whether the button is clicked or not
     if(isset($_POST['submit']))
     {
         //1. GET THE DATA FROM DATABASE
        $full_name=$_POST['full_name'];
        $username=$_POST['username'];
        $user_email=$_POST['user_email'];
        $user_contact=$_POST['user_contact'];
        $user_address=$_POST['user_address'];
        $password=md5($_POST['password']);

        //2. save the data into database
        $sql=" INSERT INTO tbl_user SET
            full_name='$full_name',
            username='$username',
            user_email='$user_email',
            user_contact='$user_contact',
            user_address='$user_address',
            password='$password'
        ";

        //3.executing query
        
        $res = mysqli_query($conn, $sql);

         //4.check whether query executed or not
         if($res==TRUE)
         {
             //DATA inserted
             //create a session to display message
             $_SESSION['useradd']="<div class='success'>User added successfully.</div>";
             //redirect page
             header('location:'.SITEURL);
         }
         else
         {
            //data not inserted
            //echo "failed to update data";
             //create a session to display message
             $_SESSION['useradd']="<div class='error'>Failed to add admin.</div>";
             //redirect page
             header('location:'.SITEURL);
         }



     }
     
?>