<?php include('partials/menu.php') ?>

<div class="main-content">
    <div class="wrapper">
         <h1>Login to your profile.</h1>
    </div>
</div>

<?php include('partials/footer.php') ?>