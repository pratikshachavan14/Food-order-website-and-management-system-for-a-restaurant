<?php include('partials/menu.php'); ?>
<!-- 
                </br>
                <a href="../profile.php" class="btn btn-primary">Back to Home Page</a><br></br> -->

        <!-- main content starts here -->
        <div class="main-content">
            <div class="wrapper">
                <h1>Your Profile</h1>
</br>

                <?php 
                   if(isset($_SESSION['useradd']))
                   {
                       echo $_SESSION['useradd'];
                       unset($_SESSION['useradd']);
                   }
                ?>

                    <table class="tbl-full">    
                        <tr>
                            <th>S.N.</th>
                            <th>Full Name</th>
                            <th>Username</th>
                            <th>Email</th>
                            <th>Contact</th>
                            <th>Address</th>
                           
                        </tr>

                        <?php 
                          
                          $sql = "SELECT * FROM tbl_user";
                          $res = mysqli_query($conn, $sql);
                          if($res==true)
                          {
                            $count = mysqli_num_rows($res);
                            
                            if($count>0)
                            {
                                while($rows=mysqli_fetch_assoc($res))
                                {
                                    $id = $rows['id'];
                                    $full_name = $rows['full_name'];
                                    $username = $rows['username'];
                                    $user_email = $rows['user_email'];
                                    $user_contact = $rows['user_contact'];
                                    $user_address = $rows['user_address'];

                                    ?>
                                     <tr>
                                     
                                            <td>1.</td>
                                            <td><?php echo $full_name; ?></td>
                                            <td><?php echo $username; ?></td>
                                            <td><?php echo $user_email; ?></td>
                                            <td><?php echo $user_contact; ?></td>
                                            <td><?php echo $user_address; ?></td>
                                            <td>
                                                <a href="" class="btn-secondary">Update Info</a>
                                                <a href="" class="btn-danger">Delete Profile</a>
                                            </td>
                                     
                                     </tr>
                                    <?php

                                }
                            }
                          }
                        
                        ?>
                            
                     </table>


            </div> 
        </div>
        <!-- main content starts here -->

        <?php include('partials/footer.php'); ?>

       