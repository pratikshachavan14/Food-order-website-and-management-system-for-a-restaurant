<?php include('partials-front/menu.php'); ?>
<br></br>

<html>
<head>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">
</head>

<div class="contact-info">
    <div><i class="fas fa-map-marker-alt"></i>  Rajarampuri 5th lane, kolhapur, Maharashtra</div><br></br>
    <div><i class="fas fa-envelope"></i>  wowfood@xxx.com</div><br></br>
    <div><i class="fas fa-phone"></i>  +91 1122334455</div><br></br>
    <div><i class="fas fa-clock"></i>  Mon - Fri 8:00 AM TO 6:00 PM</div><br></br>
</div>

<br></br><br></br><br></br><br></br><br></br>
<?php include('partials-front/footer.php'); ?>