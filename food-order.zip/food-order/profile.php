<?php include('partials-front/menu.php'); ?>

<section class="food-search1">
        <div class="container">

       
       

          <fieldset>
                      <legend><b> User Profile</b></legend>
                          

          </fieldset> 

    
                
        </div>
</section>



<?php include('partials-front/footer.php'); ?>